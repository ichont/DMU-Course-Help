﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Admin_Updt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (this.txtMM.Text.Trim() != this.txtQRMM.Text.Trim())
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('密码不一致！');</script>");
            return;
        }
        DataBase.ExecSql("update  管理员 set  密码='" + this.txtMM.Text + "'");
        Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('修改完成！');</script>");                        

    }
}
