﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class Admin_SPXXList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 在此处放置用户代码以初始化页面
        if (!Page.IsPostBack)
        {
            initGrid();
        }
    }

    protected void initGrid()
    {
        DataTable dt = new DataTable();
        dt = DataBase.Get_Table("select * from V_鲜花  ");
        if (dt.Rows.Count < 1)
            dt.Rows.Add(dt.NewRow());
        this.GridView1.DataSource = dt.DefaultView;
        this.GridView1.DataBind();

    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        //跳转页面 
        Response.Redirect("SPXXEdit.aspx");
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Mod")
        {
            //传递修改的标志 跳转页面
            string Key = this.GridView1.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString();

            Response.Redirect("SPXXEdit.aspx?ID=" + Key);
        }
        else if (e.CommandName == "Del")
        {
            string Key = this.GridView1.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString();

            //判断信息是否允许删除
            if (DataBase.Get_Table("select * from 订单信息 where 鲜花代码=" + Key + "").Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('当前鲜花信息正在使用！');</script>");                
                return;
            }
            //获取服务器相对路径
            string DPath;
            DPath = Server.MapPath("..") + @"\";
            DPath = DPath + @"Image\";
            string PicName = DataBase.Get_Table("select 图片 from 鲜花信息 where  代码=" + Key + "").Rows[0][0].ToString();
            //删除关联的图片文件
            if (File.Exists(DPath + PicName))
            {
                File.Delete(DPath + PicName);
            }
            //删除鲜花信息
            DataBase.ExecSql("delete from 鲜花信息 where 代码=" + Key + "");
            initGrid();
        }
    }


    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowIndex != -1)
        {
            if (e.Row.Cells[0].Text == "&nbsp;")
            {
                e.Row.Cells[this.GridView1.Columns.Count - 1].Visible = false;
            }
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        initGrid();
    }
}
