﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Admin_PjspPH : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            Button1_Click(null, null);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        this.GridView1.DataSource = DataBase.Get_Table("SELECT 鲜花名称,价格,分类,好评数 FROM 鲜花信息 LEFT OUTER JOIN (SELECT 代码 AS 鲜花代码, COUNT(1) AS 好评数 FROM 评价记录 WHERE 评价 = '大爱' GROUP BY 代码) A ON 鲜花信息.代码 = A.鲜花代码  ORDER BY A.好评数 DESC");
        this.GridView1.DataBind();
    }
}
