﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;

public partial class Admin_KC : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 在此处放置用户代码以初始化页面
        if (!Page.IsPostBack)
        {


            Session.Remove("imgname");
            if (Request.QueryString["ID"] != null)//从SPKC传来的
            {
                //显示当前的鲜花信息
                DataTable tmpda = new DataTable();
                tmpda = DataBase.Get_Table("select * from 鲜花信息 where 代码=" + Request.QueryString["ID"]);
                if (tmpda.Rows.Count > 0)
                {
                    this.txtSPMC.Text = tmpda.Rows[0]["鲜花名称"].ToString();
                    Image1.ImageUrl = "../image/" + tmpda.Rows[0]["图片"].ToString();
                    Session["imgname"] = tmpda.Rows[0]["图片"].ToString();
                    this.txtGG.Text = tmpda.Rows[0]["鲜花寓意"].ToString();
                    this.txtKCSL.Text = tmpda.Rows[0]["库存数量"].ToString();
                }
            }
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataBase.ExecSql("UPDATE [鲜花信息] set [库存数量] = " + Convert.ToDecimal(this.txtSJSL.Text) + "  where 代码=" + Request.QueryString["ID"]);

        Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('保存成功！');window.location.href='SPKC.aspx';</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //跳转页面
        Response.Redirect("SPKC.aspx");
    }
}
