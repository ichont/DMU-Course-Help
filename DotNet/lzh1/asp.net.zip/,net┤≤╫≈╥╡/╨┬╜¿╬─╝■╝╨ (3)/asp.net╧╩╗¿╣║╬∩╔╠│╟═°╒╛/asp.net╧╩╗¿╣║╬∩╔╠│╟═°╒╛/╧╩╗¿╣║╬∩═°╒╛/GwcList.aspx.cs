﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class GwcList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["UserID"] == null)
            {
                Response.Write("<script>alert('请先登陆！');window.location.href='Index.aspx';</script>");
            }
            else
            {
                BindGWCXX();//绑定购物车信息
            }
        }
    }

    private void BindGWCXX()//绑定购物车信息
    {
        //将购物车的当前人员的数据显示在当前列表中 
        DataTable tmpda = new DataTable();
        tmpda = DataBase.Get_Table("select * from 购物车,鲜花信息  where 购物车.鲜花代码=鲜花信息.代码 and 购物车.会员帐号='" + Session["UserID"].ToString() + "'");
        if (tmpda.Rows.Count < 1)
            tmpda.Rows.Add(tmpda.NewRow());
        this.GridView1.DataSource = tmpda;        
        this.GridView1.DataBind();
        //从数据库中计算出购物车中当前人员的总数量和总金额
        tmpda = DataBase.Get_Table("select sum(购物车.数量),sum(购物车.数量 * 鲜花信息.价格) from 购物车,鲜花信息  where 购物车.鲜花代码=鲜花信息.代码 and 购物车.会员帐号='" + Session["UserID"].ToString() + "'");
        if (tmpda.Rows.Count > 0)
        {
            this.Label2.Text = tmpda.Rows[0][0].ToString();
            this.Label1.Text = tmpda.Rows[0][1].ToString();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //删除购物车里的当前货物
        string Key = this.GridView1.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString();
        if (e.CommandName == "Del")
        {
            DataBase.ExecSql("delete from 购物车 where 购物车代码=" + Key + "");
            BindGWCXX();
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (this.Label2.Text == "" || this.Label2.Text == "&nbsp;")
            return;
        Response.Redirect("DDList.aspx");
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Index.aspx");
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (e.Row.Cells[1].Text == "" || e.Row.Cells[1].Text == "&nbsp;")
                e.Row.Cells[this.GridView1.Columns.Count - 1].Visible = false;
        }
    }
}
