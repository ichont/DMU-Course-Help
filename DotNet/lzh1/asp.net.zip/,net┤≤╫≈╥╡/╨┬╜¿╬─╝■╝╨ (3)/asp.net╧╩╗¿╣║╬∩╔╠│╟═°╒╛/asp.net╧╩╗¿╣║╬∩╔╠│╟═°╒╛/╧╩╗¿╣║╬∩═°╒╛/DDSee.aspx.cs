﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class DDSee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //根据传递的订单编号 查询 显示订单主表内容
            DataTable tmpda = new DataTable();
            tmpda = DataBase.Get_Table("select * from 订单 where 订单编号='" + Request.QueryString["ID"].ToString() + "'");//从MyDataList传来ID
            if (tmpda.Rows.Count > 0)
            {
                this.TextBox1.Text = tmpda.Rows[0]["订单编号"].ToString();
                this.TextBox2.Text = tmpda.Rows[0]["会员帐号"].ToString();
                this.TextBox3.Text = tmpda.Rows[0]["总数量"].ToString();
                this.TextBox4.Text = tmpda.Rows[0]["总金额"].ToString();
                this.TextBox6.Text = tmpda.Rows[0]["订单日期"].ToString();
                this.TextBox5.Text = tmpda.Rows[0]["付款方式"].ToString();
            }
            //显示订单明细表内容
            tmpda = DataBase.Get_Table("select * from 订单信息,鲜花信息 where 订单信息.鲜花代码=鲜花信息.代码 and 订单信息.订单编号='" + Request.QueryString["Id"].ToString() + "'");
            this.GridView1.DataSource = tmpda;
            this.GridView1.DataBind();
        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        //关闭页面
        Response.Redirect("MyDDList.aspx");
    }
}
