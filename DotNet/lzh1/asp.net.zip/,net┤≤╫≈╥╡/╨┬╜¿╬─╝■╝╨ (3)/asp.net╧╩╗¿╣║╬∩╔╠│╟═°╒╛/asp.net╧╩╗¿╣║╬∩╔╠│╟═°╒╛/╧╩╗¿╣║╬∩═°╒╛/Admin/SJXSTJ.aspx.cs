﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Admin_SJXSTJ : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            this.TextBox1.Text = DateTime.Now.ToShortDateString();
            this.TextBox2.Text = DateTime.Now.ToShortDateString();
            Button1_Click(null, null);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        this.GridView1.DataSource = DataBase.Get_Table("select 鲜花名称,价格,分类,销售数量 from 鲜花信息 ,(select 鲜花代码 ,count(1) as 销售数量  from 订单信息 where 订单编号 in (select 订单编号 from 订单 where 订单日期 between '" + TextBox1.Text + "' and '" + TextBox2.Text + "')   group by 鲜花代码) A where 鲜花信息.代码=A.鲜花代码 ");
        this.GridView1.DataBind();
    }
}
