﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_UserList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //显示会员列表
            DataTable dt = DataBase.Get_Table("select * from 会员");
            if (dt.Rows.Count < 1)
                dt.Rows.Add(dt.NewRow());
            this.GridView1.DataSource = dt.DefaultView;
            this.GridView1.DataBind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string Key = this.GridView1.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString();

        if (e.CommandName == "Mod")//没有这个
        {
            //传递修改的标志 跳转页面
            Response.Redirect("UserEdit.aspx?ID=" + Key);
        }
        else if (e.CommandName == "Del")
        {
            //判断当前的会员信息是否允许删除
           
            //删除相关的会员信息
            DataBase.ExecSql("delete from 会员 where 帐号='" + Key + "'");
            DataTable dt = DataBase.Get_Table("select * from 会员");
            if (dt.Rows.Count < 1)
                dt.Rows.Add(dt.NewRow());
            this.GridView1.DataSource = dt.DefaultView;
            this.GridView1.DataBind();
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowIndex != -1)
        {
            if (e.Row.Cells[0].Text == "&nbsp;")
                e.Row.Cells[this.GridView1.Columns.Count - 1].Visible = false;
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        DataTable dt = DataBase.Get_Table("select * from 会员");
        if (dt.Rows.Count < 1)
            dt.Rows.Add(dt.NewRow());
        this.GridView1.DataSource = dt.DefaultView;
        this.GridView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //跳转页面 
        Response.Redirect("UserEdit.aspx");
    }
}
