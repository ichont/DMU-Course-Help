﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class left : System.Web.UI.UserControl
{

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        //判断登陆人员的密码和用户是不是正确
        DataTable tmpda = new DataTable();
        tmpda = DataBase.Get_Table("select * from 会员 where 帐号='" + this.txtusername.Text.Trim() + "' and 密码='" + this.txtpassword.Text.Trim() + "'");
        if (tmpda.Rows.Count <= 0)
        {
            Response.Write("<script>alert('用户或密码错误');window.location.href='index.aspx';</script>");
            return;
        }
        else
        {
            Session["UserName"] = tmpda.Rows[0]["姓名"].ToString();
            //保存用户名到公用Session
            Session["UserID"] = this.txtusername.Text.Trim();

            Response.Redirect("index.aspx");
        }

    }

    protected void Imagebutton3_Click(object sender, ImageClickEventArgs e)
    {
        Session.Remove("UserID");
        Session.Remove("UserName");
        Response.Redirect("index.aspx");
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DataTable dt = new DataTable();
            dt = DataBase.Get_Table("select * from 系统");
            this.tInfo.InnerHtml = "<font color='#C04000'>" + dt.Rows[0]["通知"].ToString().Replace("\r\n","<br>") + "</font>";
            
            this.BindFLXX();

            if (Session["UserID"] != null)
            {
                Panel2.Visible = false;
                Panel3.Visible = true;
                username.Text = Session["UserName"].ToString();
            }
        }
    }




    public void BindFLXX()
    {
        DataTable tmpda = new DataTable();
        tmpda = DataBase.Get_Table("select * from 鲜花类别");
        DataList4.DataSource = tmpda;
        DataList4.DataBind();
    }

 


}
