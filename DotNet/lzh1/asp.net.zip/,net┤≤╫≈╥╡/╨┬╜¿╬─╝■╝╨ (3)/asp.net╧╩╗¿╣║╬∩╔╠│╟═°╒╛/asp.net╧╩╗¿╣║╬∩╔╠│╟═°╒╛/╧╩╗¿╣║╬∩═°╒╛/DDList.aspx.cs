﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class DDList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 在此处放置用户代码以初始化页面
        if (!Page.IsPostBack)
        {
            DataTable tmpda = new DataTable();//userid从UserReg传来
            tmpda = DataBase.Get_Table("select * from 购物车,鲜花信息  where 购物车.鲜花代码=鲜花信息.代码 and 购物车.会员帐号='" + Session["UserID"].ToString() + "'");
            this.GridView1.DataSource = tmpda;
            this.GridView1.DataBind();
            this.GridView1.Columns[1].Visible = false;

            //从数据库中计算出购物车中当前人员的总数量和总金额
            tmpda = DataBase.Get_Table("select sum(购物车.数量),sum(购物车.数量 * 鲜花信息.价格) from 购物车,鲜花信息  where 购物车.鲜花代码=鲜花信息.代码 and 购物车.会员帐号='" + Session["UserID"].ToString() + "'");
            if (tmpda.Rows.Count > 0)
            {
                this.TextBox3.Text = tmpda.Rows[0][0].ToString();
                this.TextBox4.Text = tmpda.Rows[0][1].ToString();
            }
            //初始化显示控件内容
            this.TextBox1.Text = Guid.NewGuid().ToString();//GUID（Global unique identifier）全局唯一标识符
            this.TextBox2.Text = Session["UserID"].ToString();
            this.TextBox6.Text = DateTime.Now.Date.ToShortDateString();
            this.LinkButton2.Attributes.Add("onclick", "return confirm('订单生成以后只能等待确认,您不能再继续操作,是否确认生成订单?');");
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("GwcList.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        if (this.GridView1.Rows.Count > 0)
        {
            //循环保存购物车中的记录到订单明细表中
            for (int i = 0; i < this.GridView1.Rows.Count; i++)
            {
                string aa = "insert into 订单信息(订单编号,鲜花代码,数量,金额) values('" + this.TextBox1.Text + "'," + Convert.ToInt32(this.GridView1.Rows[i].Cells[1].Text) + "," + Convert.ToDecimal(this.GridView1.Rows[i].Cells[4].Text) + "," + Convert.ToDecimal(this.GridView1.Rows[i].Cells[3].Text) * Convert.ToDecimal(this.GridView1.Rows[i].Cells[4].Text) + ")";
                DataBase.ExecSql("insert into 订单信息(订单编号,鲜花代码,数量,金额) values('" + this.TextBox1.Text + "'," + Convert.ToInt32(this.GridView1.Rows[i].Cells[1].Text) + "," + Convert.ToDecimal(this.GridView1.Rows[i].Cells[4].Text) + "," + Convert.ToDecimal(this.GridView1.Rows[i].Cells[3].Text) * Convert.ToDecimal(this.GridView1.Rows[i].Cells[4].Text) + ")");
            }
            //保存订单主表信息
            DataBase.ExecSql("insert into 订单(订单编号,会员帐号,总数量,总金额,订单日期,付款方式) values('" + this.TextBox1.Text + "','" + Session["UserID"].ToString() + "'," + Convert.ToDecimal(this.TextBox3.Text) + "," + Convert.ToDecimal(this.TextBox4.Text) + ",'" + this.TextBox6.Text + "','"+DropDownList1.SelectedValue+"')");
            //删除购物车记录
            //DataBase.ExecSql("delete from 购物车 where 会员帐号='" + Session["UserID"].ToString() + "'");
            Response.Redirect("Index.aspx");
        }
    }
}
