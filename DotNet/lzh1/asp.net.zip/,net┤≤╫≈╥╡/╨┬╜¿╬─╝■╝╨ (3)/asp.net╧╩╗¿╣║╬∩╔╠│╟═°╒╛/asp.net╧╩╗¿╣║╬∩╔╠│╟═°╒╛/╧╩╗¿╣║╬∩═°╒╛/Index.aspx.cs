﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["Type"] == null)//从top button传来
            {
                Session["Type"] = "";
            }

            this.BindSPXX();
            this.BindSPCount();
            this.BindOther();

        }
    }



    public void BindOther()
    {
        DataRQSP.DataSource = DataBase.Get_Table("select top 4 * from V_鲜花 order by 人气 DESC");
        DataRQSP.DataBind();
        this.DataXSPH.DataSource = DataBase.Get_Table("select top 4 * from V_销售");
        DataXSPH.DataBind();
        this.DataTJSP.DataSource = DataBase.Get_Table("select top 4 * from V_评价");
        DataTJSP.DataBind();
    }

    public void BindSPXX()
    {
        DataTable tmpda = new DataTable();
        if (Request.QueryString["spflbh"] == null)//spflbh从left传来（鲜花类别）
        {
            //显示全部的鲜花信息
            tmpda = DataBase.Get_Table("select * from V_鲜花 where 分类 like '%" + Session["Type"].ToString() + "%'");//type从top传来
        }
        else
        {
            //显示指定类型的鲜花信息
            tmpda = DataBase.Get_Table("select * from V_鲜花 where 分类 like '%" + Session["Type"].ToString() + "%' and 类别代码=" + Request.QueryString["spflbh"].ToString());            
        }

        PagedDataSource page = new PagedDataSource();
        page.DataSource = tmpda.DefaultView;
        page.AllowPaging = true;
        page.PageSize = 8;

        int curpage;
        if (Request.QueryString["page"] != null)
            curpage = int.Parse(Request.QueryString["page"]);
        else
            curpage = 1;
        page.CurrentPageIndex = curpage - 1;

        Label4.Text = "当前页:" + curpage.ToString();
        if (!page.IsFirstPage)
        {
            if (Request.QueryString["spflbh"] == null)
                HyperLink2.NavigateUrl = "Index.aspx?page=" + Convert.ToString(curpage - 1);
            else
                HyperLink2.NavigateUrl = "Index.aspx?spflbh=" + Request.QueryString["spflbh"].ToString() + "&page=" + Convert.ToString(curpage - 1);
        }
        if (!page.IsLastPage)
        {
            if (Request.QueryString["spflbh"] == null)
                HyperLink3.NavigateUrl = "Index.aspx?page=" + Convert.ToString(curpage + 1);
            else
                HyperLink3.NavigateUrl = "Index.aspx?spflbh=" + Request.QueryString["spflbh"].ToString() + "&page=" + Convert.ToString(curpage + 1);
        }

        DataList1.DataSource = page;
        DataList1.DataBind();
    }

    public void BindSPCount()
    {
        DataTable tmpda = new DataTable();
        if (Request.QueryString["spflbh"] == null)
        {
            //显示全部的鲜花信息
            tmpda = DataBase.Get_Table("select * from V_鲜花 where 分类 like '%" + Session["Type"].ToString() + "%'");
            
            if (Session["Type"].ToString() != "")
            {
                Label3.Text = Session["Type"].ToString();
            }
            else
            {
                Label3.Text = "全部鲜花";
            }
        }
        else
        {
            tmpda = DataBase.Get_Table("select * from V_鲜花 where  代码=" + Request.QueryString["spflbh"].ToString());
            if (Session["Type"].ToString() != "")
            {
                Label3.Text = Session["Type"].ToString();
            }
            else
            {
                if (tmpda.Rows.Count>0)
                { Label3.Text = tmpda.Rows[0]["类别名称"].ToString(); }
                
            }

            //显示指定类型的鲜花信息
            tmpda = DataBase.Get_Table("select * from V_鲜花 where 分类 like '%" + Session["Type"].ToString() + "%' and 类别代码=" + Request.QueryString["spflbh"].ToString());
        }

        int count = tmpda.Rows.Count;
        Label5.Text = "共有鲜花" + count.ToString() + "件";

        if (count % 8 != 0)
            Label6.Text = "共" + Convert.ToString(count / 8 + 1) + "页";
        else
            Label6.Text = "共" + Convert.ToString(count / 8) + "页";
    }

    public string GetText(string strText, int intLen)
    {
        //如果参数大于指定的长度  则省略显示
        byte[] bstr = System.Text.Encoding.GetEncoding("GB2312").GetBytes(strText.ToCharArray());

        if (bstr.Length >= intLen)
            return System.Text.Encoding.Default.GetString(bstr, 0, intLen) + "..."; 
        else
            return System.Text.Encoding.Default.GetString(bstr); 
    }

    public string GetPicPath(string picname)
    {
        return "image/" + picname;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        DataTable tmpda = new DataTable();
        tmpda = DataBase.Get_Table("select * from V_鲜花 where 鲜花名称 like '%" + TextBox1.Text + "%' ");

        PagedDataSource page = new PagedDataSource();
        page.DataSource = tmpda.DefaultView;
        page.AllowPaging = true;
        page.PageSize = 8;

        int curpage;
        if (Request.QueryString["page"] != null)
            curpage = int.Parse(Request.QueryString["page"]);
        else
            curpage = 1;
        page.CurrentPageIndex = curpage - 1;

        Label4.Text = "当前页:" + curpage.ToString();
        if (!page.IsFirstPage)
        {
            if (Request.QueryString["spflbh"] == null)
                HyperLink2.NavigateUrl = "Index.aspx?page=" + Convert.ToString(curpage - 1);
            else
                HyperLink2.NavigateUrl = "Index.aspx?spflbh=" + Request.QueryString["spflbh"].ToString() + "&page=" + Convert.ToString(curpage - 1);
        }
        if (!page.IsLastPage)
        {
            if (Request.QueryString["spflbh"] == null)
                HyperLink3.NavigateUrl = "Index.aspx?page=" + Convert.ToString(curpage + 1);
            else
                HyperLink3.NavigateUrl = "Index.aspx?spflbh=" + Request.QueryString["spflbh"].ToString() + "&page=" + Convert.ToString(curpage + 1);
        }
        int count = tmpda.Rows.Count;
        Label5.Text = "共有鲜花" + count.ToString() + "件";

        DataList1.DataSource = page;
        DataList1.DataBind();
    }
}
