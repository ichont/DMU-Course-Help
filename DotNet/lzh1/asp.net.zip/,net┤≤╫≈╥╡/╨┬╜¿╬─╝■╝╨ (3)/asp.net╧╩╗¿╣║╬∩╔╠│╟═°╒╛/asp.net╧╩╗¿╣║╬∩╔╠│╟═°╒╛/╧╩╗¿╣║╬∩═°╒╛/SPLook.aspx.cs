﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SPLook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DataBase.ExecSql("update 鲜花信息 set 人气=人气+1 where 代码 = " + Request.QueryString["spbh"].ToString());
            this.BindSPXX();

        }
    }
    protected void Imagebutton4_Click(object sender, ImageClickEventArgs e)
    {
        Session.Remove("UserID");
        Session.Remove("UserName");
        Session.Remove("PersonType");
        Response.Redirect("index.aspx");
    }


    public void BindSPXX()//绑定鲜花的信息
    {
        DataTable tmpda = new DataTable();
        tmpda = DataBase.Get_Table("select * from 鲜花信息 where 代码 = " + Request.QueryString["spbh"].ToString());
        if (tmpda.Rows.Count > 0)
        {
            DataRow dr = tmpda.Rows[0];
            Image1.ImageUrl = "image/" + dr["图片"].ToString();
            Label1.Text = dr["鲜花名称"].ToString();
            Label3.Text = dr["鲜花名称"].ToString();
            Label8.Text = dr["鲜花寓意"].ToString();
            Label6.Text = dr["价格"].ToString();
            Label10.Text = dr["库存数量"].ToString();
            this.MS.InnerHtml = dr["描述"].ToString().Replace("\r\n", "<br>");
        }
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["UserID"] == null)//从index传来spbh鲜花代码
        {
            Response.Write("<script>alert('请先登陆！');window.location.href='SPLook.aspx?spbh=" + Request.QueryString["spbh"].ToString() + "';</script>");
            return;
        }
        if (Convert.ToDecimal(Label10.Text) < Convert.ToDecimal(TextBox4.Text))
        {
            Response.Write("<script>alert('库存不足！');</script>");
            return;
        }
        DataTable tmpda;
        tmpda = DataBase.Get_Table("select * from 购物车 where 会员帐号='" + Session["UserId"].ToString() + "' and 鲜花代码=" + Request.QueryString["spbh"].ToString());
        if (tmpda.Rows.Count > 0)//如果购物车有这个物品直接更新数量就可以了，如果没有表示第一次购买，那么就插入insert
        {
            DataBase.ExecSql("update 购物车 set 数量=数量 +" + this.TextBox4.Text.Trim() + " where 会员帐号='" + Session["UserId"].ToString() + "' and 鲜花代码=" + Request.QueryString["spbh"].ToString());
        }
        else
        {
            DataBase.ExecSql("insert into 购物车(会员帐号,鲜花代码,数量) values('" + Session["UserId"].ToString() + "'," + Request.QueryString["spbh"].ToString() + "," + this.TextBox4.Text.Trim() + ")");
        }

        Response.Redirect("GwcList.aspx");
    }


    public string GetText(string strText, int intLen)
    {
        //如果参数大于指定的长度  则省略显示
        byte[] bstr = System.Text.Encoding.GetEncoding("GB2312").GetBytes(strText.ToCharArray());

        if (bstr.Length >= intLen)
            return System.Text.Encoding.Default.GetString(bstr, 0, intLen) + "...";
        else
            return System.Text.Encoding.Default.GetString(bstr);
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["UserID"] == null)
        {
            Response.Write("<script>alert('请先登陆！');window.location.href='SPLook.aspx?spbh=" + Request.QueryString["spbh"].ToString() + "';</script>");
            return;
        }
        DataBase.ExecSql("insert into 评价记录(帐号,代码,评价) values('" + Session["UserId"].ToString() + "'," + Request.QueryString["spbh"].ToString() + ",'" + RadioButtonList1.SelectedValue + "')");
        Response.Write("<script>alert('谢谢您的评价！');</script>");

    }
}
