﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class MyDDList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //根据当前的登陆人员不同 然后控制登陆人员使用权限
            DataTable tmpda = new DataTable();
            if (Session["UserID"] != null)
            {
                //加载指定人员的订单列表
                DataTable dt = DataBase.Get_Table("select * from 订单 where 会员帐号='" + Session["UserID"].ToString() + "' order by 订单日期 DESC ");
                if (dt.Rows.Count < 1)
                    dt.Rows.Add(dt.NewRow());
                this.GridView1.DataSource = dt.DefaultView;
                this.GridView1.DataBind();
                this.GridView1.Columns[0].Visible = false;
            }
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "SeeDD")
        {
            //打开订单信息窗体
            string Key = this.GridView1.DataKeys[Convert.ToInt32(e.CommandArgument)]["订单编号"].ToString();
            Response.Redirect("DDSee.aspx?ID=" + Key + "");
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowIndex != -1)
        {
            if (e.Row.Cells[0].Text == "&nbsp;")
            {
                e.Row.Cells[this.GridView1.Columns.Count - 1].Visible = false;
            }
        }
    }
}
