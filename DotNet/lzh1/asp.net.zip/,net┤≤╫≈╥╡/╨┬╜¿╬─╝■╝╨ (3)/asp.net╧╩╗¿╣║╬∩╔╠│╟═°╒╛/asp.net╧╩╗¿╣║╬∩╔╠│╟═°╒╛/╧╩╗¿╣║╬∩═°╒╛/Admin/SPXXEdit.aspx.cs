﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class Admin_SPXXEdit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 在此处放置用户代码以初始化页面
        if (!Page.IsPostBack)
        {
            //绑定类别列表
            this.drSPFL.DataTextField = "类别名称";
            this.drSPFL.DataValueField = "代码";
            this.drSPFL.DataSource = DataBase.Get_Table("select * from 鲜花类别");
            this.drSPFL.DataBind();

            Session.Remove("imgname");
            if (Request.QueryString["ID"] != null)//从SPXXLIST传过来的ID
            {
                //显示当前的鲜花信息
                DataTable tmpda = new DataTable();
                tmpda = DataBase.Get_Table("select * from 鲜花信息 where 代码=" + Request.QueryString["ID"]);
                if (tmpda.Rows.Count > 0)
                {
                    this.txtSPMC.Text = tmpda.Rows[0]["鲜花名称"].ToString();
                    this.txtMS.Text = tmpda.Rows[0]["描述"].ToString();
                    Image1.ImageUrl = "../image/" + tmpda.Rows[0]["图片"].ToString();
                    Session["imgname"] = tmpda.Rows[0]["图片"].ToString();
                    this.txtSJ.Text = tmpda.Rows[0]["价格"].ToString();
                    this.txtGG.Text = tmpda.Rows[0]["鲜花寓意"].ToString();
                    this.drSPFL.SelectedValue = tmpda.Rows[0]["类别代码"].ToString();
                    this.rdLB.SelectedValue = tmpda.Rows[0]["分类"].ToString();
                }
            }
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //判断信息是否正确
        if (this.txtSPMC.Text.Trim() == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('鲜花名称不能为空！');</script>");            
            return;
        }

        //将相关的图片上传到@"Image\"路径下
        string FileName = "";
        string FileName1;
        string DPath;
        DPath = Server.MapPath("..") + @"\";
        DPath = DPath + @"Image\";
        if (this.File1.PostedFile.FileName != "")
        {
            string[] temp = this.File1.PostedFile.FileName.Split('.');
            string strHzm = "." + temp[temp.Length - 1];

            Guid tmp = Guid.NewGuid();
            FileName = tmp.ToString() + strHzm;
            FileName1 = DPath + tmp.ToString() + strHzm;
            this.File1.PostedFile.SaveAs(FileName1);
            if (Session["imgname"] != null)
            {
                if (File.Exists(DPath + Session["imgname"].ToString()))
                {
                    File.Delete(DPath + Session["imgname"].ToString());
                }
            }
        }

        //根据标志判断是添加还是修改的操作 保存鲜花信息
        if (Request.QueryString["ID"] != null)
        {
            if (FileName == "")
            {
                DataBase.ExecSql("UPDATE [鲜花信息] set [鲜花名称] = '" + txtSPMC.Text + "',[鲜花寓意] = '" + txtGG.Text + "',[描述] = '" + txtMS.Text + "',[类别代码] =" + drSPFL.SelectedValue + ",[价格] = " + txtSJ.Text + ",分类='" + rdLB.SelectedValue + "' where 代码=" + Request.QueryString["ID"]);
            }
            else
            {
                DataBase.ExecSql("UPDATE [鲜花信息] set [鲜花名称] = '" + txtSPMC.Text + "',[鲜花寓意] = '" + txtGG.Text + "',[描述] = '" + txtMS.Text + "',[类别代码] =" + drSPFL.SelectedValue + ",[价格] = " + txtSJ.Text + ",[图片]='" + FileName + "',分类='" + rdLB.SelectedValue + "' where 代码=" + Request.QueryString["ID"]);
            }
        }
        else
        {
            DataBase.ExecSql("INSERT INTO [鲜花信息] ( [鲜花名称] ,[鲜花寓意] ,[描述] ,[类别代码] ,[图片] ,[价格],[分类] ) VALUES ('" + txtSPMC.Text + "','" + txtGG.Text + "','" + txtMS.Text + "'," + drSPFL.SelectedValue + ",'" + FileName + "'," + txtSJ.Text + ",'" + rdLB.SelectedValue + "')");

        }
        Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('保存成功！');window.location.href='SPXXList.aspx';</script>");        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //跳转页面
        Response.Redirect("SPXXList.aspx");
    }
}
