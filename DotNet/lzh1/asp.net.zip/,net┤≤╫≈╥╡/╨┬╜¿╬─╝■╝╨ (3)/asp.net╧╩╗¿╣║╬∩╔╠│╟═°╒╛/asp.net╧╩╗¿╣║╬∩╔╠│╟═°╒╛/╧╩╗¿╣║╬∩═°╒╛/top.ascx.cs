﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class top : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            this.p02.Visible = true;
            this.p03.Visible = true;
        }
        
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Session["Type"] = "";
        Response.Redirect("Index.aspx");
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Session["Type"] = "特价鲜花";
        Response.Redirect("Index.aspx");
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session["Type"] = "推荐鲜花";
        Response.Redirect("Index.aspx");
    }
}
