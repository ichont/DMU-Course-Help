﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class UpdatePWd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 在此处放置用户代码以初始化页面
        if (!Page.IsPostBack)
        {
            //绑定类别列表

            DataTable tmpda = new DataTable();
            tmpda = DataBase.Get_Table("select * from 会员  where  帐号='" + Session["UserID"] + "'");//session【id】注册的时候从UserReg传来
            if (tmpda.Rows.Count > 0)
            {
                this.txtZH.Text = tmpda.Rows[0]["帐号"].ToString();
                this.txtLXDH.Text = tmpda.Rows[0]["联系电话"].ToString();
                this.txtDZ.Text = tmpda.Rows[0]["地址"].ToString();
                this.txtDZSF.Text = tmpda.Rows[0]["身份证"].ToString();
                this.txtLXR.Text = tmpda.Rows[0]["姓名"].ToString();

            }
        }


    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (this.txtMM.Text.Trim() != this.txtQRMM.Text.Trim())
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('密码不一致！');</script>");
            return;
        }
        DataBase.ExecSql("update  会员 set  密码='" + this.txtMM.Text + "' where  帐号='" + Session["UserID"] + "'");
        Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('修改完成！');</script>");

    }
}
