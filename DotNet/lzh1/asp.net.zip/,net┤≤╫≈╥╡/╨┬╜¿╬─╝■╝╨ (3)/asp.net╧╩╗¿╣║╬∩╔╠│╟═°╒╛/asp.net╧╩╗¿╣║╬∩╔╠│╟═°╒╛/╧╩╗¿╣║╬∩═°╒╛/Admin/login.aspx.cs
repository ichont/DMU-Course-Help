﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// 系统登录页面
/// </summary>
public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

			
    }
 


    protected void ImgButLog_Click(object sender, ImageClickEventArgs e)
    {
        //判断当前的登陆角色 根据不同的登陆角色判断从那个数据库表格检索用户登陆信息
        DataTable dt = DataBase.Get_Table("select * from 管理员 where 帐号='" + TextBox1.Text + "' and 密码='" + TextBox2.Text + "'");
        if (dt.Rows.Count > 0)
        {
            Response.Redirect("Index.aspx");
            
        }
        else
        {
            Page.RegisterClientScriptBlock("onload", "<script>alert('密码错误');</script>");
            return;
        }
    }



}