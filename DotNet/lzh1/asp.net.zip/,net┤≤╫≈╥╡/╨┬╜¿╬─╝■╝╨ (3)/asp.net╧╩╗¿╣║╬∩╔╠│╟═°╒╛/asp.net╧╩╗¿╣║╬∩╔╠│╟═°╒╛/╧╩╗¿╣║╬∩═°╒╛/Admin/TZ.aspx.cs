﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Admin_TZ : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DataTable dt = new DataTable();
            dt = DataBase.Get_Table("select * from 系统");
            this.txtTZ.Text= dt.Rows[0]["通知"].ToString();

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataBase.ExecSql("UPDATE [系统] set [通知] = '" + this.txtTZ.Text + "'");

        Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('保存通知成功！');</script>");        
 
    }
}
