﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class UserReg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    
    }

    protected void Imagebutton2_Click(object sender, ImageClickEventArgs e)
    {
        //判断信息是否正确
        if (this.txtZH.Text.Trim() == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('会员帐号不能为空！');</script>");
            return;
        }
        if (this.txtDZSF.Text.Length <= 18)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('身份证号不能少于18位！');</script>");
            return;
        }
        if (this.txtMM.Text.Trim() != this.txtQRMM.Text.Trim())
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('密码不一致！');</script>");
            return;
        }
        DataTable tmpda = new DataTable();
        tmpda = DataBase.Get_Table("select * from 会员 where 帐号='" + txtZH.Text + "'");
        if (tmpda.Rows.Count > 0)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('此帐户已经存在,请重新输入！');</script>");
            return;
        }

        //添加注册的会员信息到数据库中
        DataBase.ExecSql("INSERT INTO [会员] ( [帐号] ,[密码] ,[姓名] ,[性别] ,[联系电话] ,[地址] ,[身份证] ) VALUES ('"+txtZH.Text+"','"+txtQRMM.Text+"','"+txtLXR.Text+"','"+drDPFL.SelectedValue+"','"+txtLXDH.Text+"','"+txtDZ.Text+"','"+txtDZSF.Text+"')");


        Session["UserName"] = this.txtLXR.Text.Trim();
        Session["UserID"] = this.txtZH.Text.Trim();

        Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('保存成功！');window.location.href='Index.aspx';</script>");
    }
}
