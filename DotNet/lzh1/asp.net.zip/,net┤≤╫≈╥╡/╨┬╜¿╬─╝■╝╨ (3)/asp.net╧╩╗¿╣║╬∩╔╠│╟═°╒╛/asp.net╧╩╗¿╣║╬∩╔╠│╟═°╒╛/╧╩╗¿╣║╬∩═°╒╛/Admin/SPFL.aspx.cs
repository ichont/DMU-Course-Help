﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_SPFL : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 在此处放置用户代码以初始化页面
        if (!Page.IsPostBack)
        {
            //调用函数
            initDg();
        }
    }

    private void initDg()
    {
        //显示类别列表
        this.GridView1.DataSource = DataBase.Get_Table("select * from 鲜花类别");
        this.GridView1.DataBind();
        this.TextBox1.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //判断信息是否正确
        if (this.TextBox1.Text.Trim() == "")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('类别名称不能为空！');</script>");            
            return;
        }
        if (DataBase.Get_Table("select * from 鲜花类别 where 类别名称='" + this.TextBox1.Text.Trim() + "'").Rows.Count > 0)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('类别名称重复！');</script>");                        
            return;
        }
        //添加类别信息
        DataBase.ExecSql("insert into 鲜花类别(类别名称) values('" + this.TextBox1.Text.Trim() + "')");
        initDg();
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Del")
        {
            //判断记录是否允许删除
            string Key = this.GridView1.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString();
            if (DataBase.Get_Table("select * from 鲜花信息 where 类别代码=" + Key + "").Rows.Count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('当前鲜花分类正在使用！');</script>");                                        
                return;
            }
            //删除记录  刷新列表
            DataBase.ExecSql("delete from 鲜花类别 where 代码=" + Key);
            initDg();
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.GridView1.PageIndex = e.NewPageIndex;
        initDg();
    }
}
