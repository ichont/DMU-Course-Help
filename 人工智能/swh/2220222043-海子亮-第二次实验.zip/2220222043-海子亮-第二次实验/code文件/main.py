#特征，综合数据库
features = ["有奶", "有毛发", "有羽毛", "会飞", "会下蛋",  \
            "吃肉", "有犬齿", "有爪","眼盯前方", "有蹄", "嚼反刍",\
            "黄褐色", "身上有暗斑点", "身上有黑色条纹", "有长脖子", \
            "有长腿", "不会飞", "会游泳", "有黑白二色", "善飞",\
            "哺乳动物", "鸟", "食肉动物", "蹄类动物", "金钱豹", "虎",\
            "长颈鹿", "斑马", "鸵鸟", "企鹅", "信天翁"]

#规则库
rule1 = [2]   # if 动物有毛发2  then  动物是哺乳动物21
rule2 = [1]   # if 动物有奶1  then  动物是哺乳动物21

rule3 = [3]   # if 动物有羽毛3  then  动物是鸟22
rule4 = [4, 5]  # if 动物会飞4 and  会生蛋5 then  动物是鸟22

rule5 = [6]  # if 动物吃肉6 then 动物是食肉动物23
rule6 = [7, 8, 9]  # if 动物有犀利牙齿7 and 有爪8 and 眼向前方9 then 动物是食肉动物23

rule7 = [21, 10]  # if 动物是哺乳动物21 and 有蹄10 then 动物是有蹄类动物24
rule8 = [21, 11]  # if 动物是哺乳动物21 and 反刍11 then 动物是有蹄类动物24

rule9 = [21, 23, 12, 13]  # if 动物是哺乳动物21 and 是食肉动物23 and 有黄褐色12 and 有暗斑点13 then 动物是豹25
rule10 = [21, 23, 12, 14]  # if 动物是哺乳动物21 and 是食肉动物23 and 有黄褐色12 and 有黑色条纹14 then 动物是虎26
rule11 = [24, 15, 16, 13]  # if动物是有蹄类动物24  and 有长脖子15 and 有长腿16 and 有暗斑点13 then 动物是长颈鹿27
rule12 = [24, 14]  # if 动物是有蹄类动物24 and 有黑色条纹14 then 动物是斑马28
rule13 = [22, 17, 16, 15, 19]  # if 动物是鸟22 and 不会飞17 and 有长脖子16 and 有长腿15 and 有黑白二色15 then 动物是鸵鸟29
rule14 = [22, 17, 18, 19]  # if 动物是鸟22 and 不会飞17 and 会游泳18 and 有黑白二色19 then  动物是企鹅30
rule15 = [22, 4, 5]  # if 动物是鸟22 and善飞4 and 会生蛋5 then 动物是信天翁31

print('以下是一些动物的特征：')
i = 0
while i < 24:
    print('%d' %(i+1) +'.'+ features[i]+ '  ', end='')
    i = i+1
    if i % 8 == 0:
        print('\n')

print('以下是可识别的动物：')
while i < 31:
    print('%d' %(i+1) +'.'+ features[i]+ '  ', end='')
    i = i+1

flag= int(input('\n请选择\n1:正向推理\n2:反向推理\n'))
if flag==1:
    answer = input('\n请选择动物的特征编号，用空格隔开，回车结束输入：')
    # 接收到的answer是一个字符串
    answer = list(answer.split())
    new_answer = [int(x) for x in answer]
    print("事实库：",new_answer)

    print("正向推理过程如下：")
    if set(rule1)<=set(new_answer):
        print('rule1：2->21\tif 动物有毛发2  then  动物是哺乳动物21')
        new_answer.append(21)
    if set(rule2)<=set(new_answer):
        print('rule2：1->21\tif 动物有奶1  then  动物是哺乳动物21')
        new_answer.append(21)
    if set(rule3)<=set(new_answer):
        print('rule3：3->22\tif 动物有羽毛3  then  动物是鸟22')
        new_answer.append(22)
    if set(rule4)<=set(new_answer):
        print('rule4：4+5->22\tif 动物会飞4 and  会生蛋5 then  动物是鸟22')
        new_answer.append(22)
    if set(rule5)<=set(new_answer):
        print('rule5：6->23\tif 动物吃肉6 then 动物是食肉动物23')
        new_answer.append(23)
    if set(rule6)<=set(new_answer):
        print('rule6：7+8+9->23\tif 动物有犀利牙齿7 and 有爪8 and 眼向前方9 then 动物是食肉动物23')
        new_answer.append(23)
    if set(rule7)<=set(new_answer):
        print('rule7：21+10->24\tif 动物是哺乳动物21 and 有蹄10 then 动物是有蹄类动物24')
        new_answer.append(24)
    if set(rule8)<=set(new_answer):
        print('rule8：21+11->24\tif 动物是哺乳动物21 and 反刍11 then 动物是有蹄类动物24')
        new_answer.append(24)

    print("正向推理结果为：",new_answer)


    if set(rule9)<=set(new_answer):
        print("if 动物是哺乳动物21 and 是食肉动物23 and 有黄褐色12 and 有暗斑点13 then 动物是豹25")
        print("结果为：", end=" ")
        print(features[24])
    elif set(rule10)<=set(new_answer):
        print("if 动物是哺乳动物21 and 是食肉动物23 and 有黄褐色12 and 有黑色条纹14 then 动物是虎26")
        print("结果为：", end=" ")
        print(features[25])
    elif set(rule11)<=set(new_answer):
        print("if动物是有蹄类动物24  and 有长脖子15 and 有长腿16 and 有暗斑点13 then 动物是长颈鹿27")
        print("结果为：", end=" ")
        print(features[26])
    elif set(rule12)<=set(new_answer):
        print("if 动物是有蹄类动物24 and 有黑色条纹14 then 动物是斑马28")
        print("结果为：", end=" ")
        print(features[27])
    elif set(rule13)<=set(new_answer):
        print("if 动物是鸟22 and 不会飞17 and 有长脖子16 and 有长腿15 and 有黑白二色15 then 动物是鸵鸟29")
        print("结果为：", end=" ")
        print(features[28])
    elif set(rule14)<=set(new_answer):
        print("if 动物是鸟22 and 不会飞17 and 会游泳18 and 有黑白二色19 then  动物是企鹅30")
        print("结果为：", end=" ")
        print(features[29])
    elif set(rule15)<=set(new_answer):
        print("if 动物是鸟22 and善飞4 and 会生蛋5 then 动物是信天翁31")
        print("结果为：", end=" ")
        print(features[30])
    else:
        print('识别失败！')
elif flag==2:
    animal=int(input('\n请选择动物的种类编号，回车结束输入：'))
    answer = input('\n请选择动物的特征编号，用空格隔开，回车结束输入：')
    # 接收到ans的wer是一个字符串
    answer = list(answer.split())
    new_answer = [int(x) for x in answer]
    print("事实库：", new_answer)
    print("逆向推理过程如下：")
    real=[]
    if animal==25:
        print(features[animal-1],'rule9：25->21,23,12,13  if 动物是哺乳动物21 and 是食肉动物23 and 有黄褐色12 and 有暗斑点13 then 动物是豹25')
        real=rule9
    elif animal==26:
        print(features[animal-1],'rule10：26->21,23,12,114  if 动物是哺乳动物21 and 是食肉动物23 and 有黄褐色12 and 有黑色条纹14 then 动物是虎26')
        real=rule10
    elif animal==27:
        print(features[animal-1],'rule11：27->24, 15, 16, 13  if动物是有蹄类动物24  and 有长脖子15 and 有长腿16 and 有暗斑点13 then 动物是长颈鹿27')
        real=rule11
    elif animal==28:
        print(features[animal-1],'rule12：28->24, 14  if 动物是有蹄类动物24 and 有黑色条纹14 then 动物是斑马28')
        real=rule12
    elif animal==29:
        print(features[animal-1],'rule13：29->22, 17, 16, 15, 19  if 动物是鸟22 and 不会飞17 and 有长脖子16 and 有长腿15 and 有黑白二色15 then 动物是鸵鸟29')
        real=rule13
    elif animal==30:
        print(features[animal-1],'rule14：30->22, 17, 18, 19  if 动物是鸟22 and 不会飞17 and 会游泳18 and 有黑白二色19 then  动物是企鹅30')
        real=rule14
    elif animal==31:
        print(features[animal-1],'rule15：31->22, 4, 5  if 动物是鸟22 and善飞4 and 会生蛋5 then 动物是信天翁31')
        real=rule15
    key=0
    for i in real:
            if i in new_answer:
                print(i)
                continue
            elif i ==21:
                if set(rule1)<=set(new_answer) :
                    print("rule1:21->2  if 动物有毛发2  then  动物是哺乳动物21")
                    continue
                elif set(rule2)<=set(new_answer):
                    print("rule2:21->1  if 动物有奶1  then  动物是哺乳动物21")
                    continue
            elif i==22:
                if set(rule3) <= set(new_answer):
                    print("rule3:22->3  if 动物有羽毛3  then  动物是鸟22")
                    continue
                elif set(rule4) <= set(new_answer):
                    print("rule4:22->4,5  if 动物会飞4 and  会生蛋5 then  动物是鸟22")
                    continue
            elif i == 23:
                if set(rule5) <= set(new_answer):
                    print("rule5:23->6  if 动物吃肉6 then 动物是食肉动物23")
                    continue
                elif set(rule6) <= set(new_answer):
                    print("rule6:23->7,8,9  if 动物有犀利牙齿7 and 有爪8 and 眼向前方9 then 动物是食肉动物23")
                    continue
            elif i == 24:
                if set(rule7) <= set(new_answer) :
                    print("rule7:24->21,10  if 动物是哺乳动物21 and 有蹄10 then 动物是有蹄类动物24")
                    continue
                elif set(rule8) <= set(new_answer):
                    print("rule8:24->21,11  if 动物是哺乳动物21 and 反刍11 then 动物是有蹄类动物24")
                    continue
            else:
                key=1
    if key==0:
            print("推导成功！")
    elif key==1:
            print("推导失败！")
input("输入任意字符结束")