package lazy1.android.mytodolist;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.support.v7.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ListView mListView;
    private List<Comment> mTweets;
    private Comment mComment;
    private Calendar ca=Calendar.getInstance();;
    private TextView mTextStatus;
    private int count=0;
    int  mYear = ca.get(Calendar.YEAR);
    int  mMonth = ca.get(Calendar.MONTH);
    int  mDay = ca.get(Calendar.DAY_OF_MONTH);
    private FloatingActionButton addButton;
    private FloatingActionButton clearButton;
    private FloatingActionButton moreButton;
    private SearchView searchview;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search,menu);
        //获取搜索菜单组件
        MenuItem menuItem=menu.findItem(R.id.search);
        searchview=(SearchView) menuItem.getActionView();
        searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Toast t = Toast.makeText(MainActivity.this, query, Toast.LENGTH_SHORT);
                t.setGravity(Gravity.TOP,0,0);
                t.show();
                Intent intent=new Intent();
                intent.setClass(MainActivity.this,Search.class);
                intent.putExtra("title",query);
                startActivity(intent);
                overridePendingTransition(R.anim.trans_in, R.anim.no_anim);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        //获取分享的菜单子组件
        MenuItem shareItem = menu.findItem(R.id.share);
        return super.onCreateOptionsMenu(menu);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 绑定UI

        mTextStatus = (TextView) findViewById(R.id.list_status);
        mListView = (ListView) findViewById(R.id.list);
        addButton = (FloatingActionButton)  findViewById(R.id.addButton);
        clearButton = (FloatingActionButton) findViewById(R.id.clearButton);
        moreButton=(FloatingActionButton)findViewById(R.id.moreButton);
        mTweets = generateData();
        refreshList();
        addButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                addDialog();
            }
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                clearDialog();
            }
        });

        moreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent();
                intent.setClass(MainActivity.this,MoreActivity.class);
                intent.putExtra("num",String.valueOf(count));
                startActivity(intent);
                overridePendingTransition(R.anim.trans_in, R.anim.no_anim);
            }
        });
        mListView.setLongClickable(true);

        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos, long id) {
                deleteOne(pos);
                return true;
            }
        });

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                modifyOne(position);
            }
        });
    }

    // 删除对话
    private void deleteOne(int pos) {
        final int position = pos;
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(R.string.deleteOne_title);
        alert.setMessage(R.string.deleteOne_message);

        alert.setPositiveButton(R.string.app_yes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                deleteOnePos(position);
                refreshList();
            }
        });

        alert.setNegativeButton(R.string.app_no, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        alert.show();
    }
    //显示日期
    private String showDateDialog(Context context,int themeResId){

        DatePickerDialog datePickerDialog=new   DatePickerDialog(context,themeResId,new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayofmonth) {
                Toast.makeText(getApplicationContext(), "你选择的是 "+year+"年"+(month+1)+"月"+dayofmonth+"日", Toast.LENGTH_SHORT).show();
                mYear=year;
                mDay=dayofmonth;
                mMonth=month;
            }
        }, mYear, mMonth, mDay);
        datePickerDialog.show();
        final String date=(mYear)+"-"+(mMonth+1)+"-"+mDay;
        return date;
    }
    //清除对话框
    private void clearDialog() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("清除所有事项");
        alert.setMessage(R.string.clear);

        alert.setPositiveButton("是", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                deleteAll();
                refreshList();
            }
        });

        alert.setNegativeButton("退出", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        alert.show();
    }
    //添加一个待办事项
    private void addDialog() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(R.string.addOne_title);
        alert.setMessage(R.string.addOne_message);

        // Create TextView
        final EditText name = new EditText (this);
        name.setHint(R.string.addOne_name);
        final EditText text = new EditText(this);
        text.setHint(R.string.addOne_task);
        final EditText date = new EditText(this);
        date.setHint("双击选择deadline");
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                date.setText(showDateDialog(MainActivity.this,0));
            }
        });
        // check是否重要
        final CheckBox importantCheck = new CheckBox(this);
        importantCheck.setText(R.string.addOne_important);

        Context context = getApplicationContext();
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(70, 0, 70, 0);

        layout.addView(name, layoutParams);
        layout.addView(text, layoutParams);
        layout.addView(date,layoutParams);
        layout.addView(importantCheck, layoutParams);

        alert.setView(layout);

        alert.setPositiveButton(R.string.app_ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                Random rnd = new Random();
                int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));

                String important;
                if(importantCheck.isChecked()) {
                    important = "y";
                }
                else {
                    important = "n";
                }
                String notCompleted="n";
                if(name.length() > 0 || text.length() > 0) {
                    mComment = new Comment(color, name.getText().toString(), date.getText().toString(),notCompleted,text.getText().toString(), important);
                    AddItem(mComment);
                    refreshList();
                }
            }
        });

        alert.setNegativeButton(R.string.app_cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        alert.show();
    }
    //更改
    private void modifyOne(final int position) {

        mComment = mTweets.get(position);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(R.string.modifyOne_title);
        alert.setMessage(R.string.modifyOne_message);

        final EditText name = new EditText (this);
        name.setText(mComment.getPseudo());
        final EditText text = new EditText(this);
        text.setText(mComment.getText());
        final EditText date = new EditText(this);
        date.setText(mComment.getDate());

        final CheckBox importantCheck = new CheckBox(this);
        importantCheck.setText(R.string.addOne_important);
        final CheckBox complete=new CheckBox(this);
        complete.setText("完成");
        if(mComment.getIsCompleted().equals("y")){
            complete.setChecked(true);
        }
        if(mComment.getImportant().equals("y")) {
            importantCheck.setChecked(true);
        }

        Context context = getApplicationContext();
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(70, 0, 70, 0);

        layout.addView(name, layoutParams);
        layout.addView(text, layoutParams);
        layout.addView(date,layoutParams);
        layout.addView(complete,layoutParams);
        layout.addView(importantCheck, layoutParams);

        alert.setView(layout);


        alert.setPositiveButton(R.string.app_modify, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                String important;
                if(importantCheck.isChecked()) {
                    important = "y";
                }
                else {
                    important = "n";
                }
                String iscompleted;
                if(complete.isChecked()){
                    iscompleted="y";
                }else{
                    iscompleted="n";
                }
                if(name.length() > 0 || text.length() > 0) {
                    //System.out.println(date.getText().toString());
                    mComment = new Comment(mComment.getColor(), name.getText().toString(), date.getText().toString(),iscompleted,text.getText().toString(), important);
                    ModifyItem(position, mComment);
                    refreshList();
                }
            }
        });

        alert.setNegativeButton(R.string.app_cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        alert.show();


    }

    // 刷新列表
    public void refreshList() {
        RowAdapter adapter = new RowAdapter(MainActivity.this, mTweets);
        mListView.setAdapter(adapter);

        if(mTweets.size() > 0 ) {
            mTextStatus.setText(R.string.app_listNoEmpty);
        }
        else {
            mTextStatus.setText(R.string.app_listEmpty);
        }
    }

    // 生成数据
    private List<Comment> generateData() {
        mTweets = new ArrayList<>();
        SharedPreferences myPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        String myData = myPrefs.getString("myTodoData",null);
        //记录已完成的事项
        ArrayList iscompleted=new ArrayList();
        if(myData != null)
        {
            try {
                JSONArray jsonArray = new JSONArray(myData);
                for (int i = 0; i < jsonArray.length(); i++)
                {
                    String data  = jsonArray.getString(i);
                    String[] splitData = data.split("\\.");
                    //如果不是已完成事项，插入
                    if(splitData[3].equals("n")) {
                        mTweets.add(new Comment(Integer.parseInt(splitData[0]), splitData[1], splitData[2], splitData[3], splitData[4], splitData[5]));
                    }else{
                        iscompleted.add(i);
                    }
                }
                //添加已完成的事项
                for(int i=0;i<iscompleted.size();i++) {
                    String data = jsonArray.getString((int)iscompleted.get(i));
                    String[] splitData = data.split("\\.");
                    mTweets.add(new Comment(Integer.parseInt(splitData[0]), splitData[1], splitData[2], splitData[3], splitData[4], splitData[5]));
                    count++;//统计已完成的事项个数
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return mTweets;
    }
    //调整列表
    private void ModifyItem(int position, Comment e) {
        SharedPreferences myPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        String myData = myPrefs.getString("myTodoData",null);

        JSONArray jsonArray = null;

        try {
            jsonArray = new JSONArray(myData);
            jsonArray.remove(position);
            //更新已完成的事项个数
            if(e.getIsCompleted().equals("y")){
                count++;
            }else{
                count--;
            }
            jsonArray.put(e.getColor() + "." + e.getPseudo() + "." +e.getDate()+'.'+e.getIsCompleted()+'.'+ e.getText() + "." + e.getImportant());
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        mTweets.remove(position);
        mTweets.add(e);

        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("myTodoData", jsonArray != null ? jsonArray.toString() : null);
        editor.apply();
    }
    //添加提醒事项
    private void AddItem(Comment e) {
        SharedPreferences myPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        String myData = myPrefs.getString("myTodoData",null);

        JSONArray jsonArray = null;
        if(myData == null) {
            jsonArray = new JSONArray();
            jsonArray.put(e.getColor() + "." + e.getPseudo() + "." +e.getDate()+'.'+e.getIsCompleted()+'.'+ e.getText() + "." + e.getImportant());
            mTweets.add(e);
        }
        else {
            try {
                jsonArray = new JSONArray(myData);
                jsonArray.put(e.getColor() + "." + e.getPseudo() + "." + e.getDate()+'.'+e.getIsCompleted()+'.'+e.getText() + "." + e.getImportant());
                mTweets.add(e);
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
        }

        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("myTodoData", jsonArray != null ? jsonArray.toString() : null);
        editor.apply();
    }
    //删除某一个提醒事项
    private void deleteOnePos(int pos) {
        SharedPreferences myPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        String myData = myPrefs.getString("myTodoData",null);

        JSONArray jsonArray = null;
        try {
            jsonArray = new JSONArray(myData);

            jsonArray.remove(pos);
            mTweets.remove(pos);
        } catch (JSONException e1) {
            e1.printStackTrace();
        }

        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("myTodoData", jsonArray != null ? jsonArray.toString() : null);
        editor.apply();
    }
    //删除所有的事项
    private void deleteAll() {
        SharedPreferences myPrefs = PreferenceManager.getDefaultSharedPreferences(this);

        JSONArray jsonArray = new JSONArray();
        mTweets = new ArrayList<>();

        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("myTodoData", jsonArray.toString());
        editor.apply();
    }

}
