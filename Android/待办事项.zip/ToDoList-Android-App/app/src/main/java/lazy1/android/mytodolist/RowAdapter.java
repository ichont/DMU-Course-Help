package lazy1.android.mytodolist;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class RowAdapter extends ArrayAdapter<Comment> {

    public RowAdapter(Context context, List<Comment> tweets) {
        super(context, 0, tweets);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.row_list,parent, false);
        }

        TweetViewHolder viewHolder = (TweetViewHolder) convertView.getTag();
        if(viewHolder == null){
            viewHolder = new TweetViewHolder();
            viewHolder.title = (TextView) convertView.findViewById(R.id.pseudo);
            viewHolder.date=(TextView)convertView.findViewById(R.id.date);
            viewHolder.text = (TextView) convertView.findViewById(R.id.text);
            viewHolder.avatar = (ImageView) convertView.findViewById(R.id.avatar);
            convertView.setTag(viewHolder);
        }

        Comment tweet = getItem(position);
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        Date nowTime = new Date(System.currentTimeMillis());
//        String todayDate = sdf.format(nowTime);
//        if(todayDate.compareTo(tweet.getDate())>=0){
//            viewHolder.date.setTextColor(Color.parseColor("#FF0000"));
//        }
        if(tweet.getImportant().equals("y")) {
            viewHolder.text.setTextColor(Color.parseColor("#FF0000"));
        }

        if(tweet.getImportant().equals("n")) {
            viewHolder.text.setTextColor(Color.parseColor("#000000"));
        }
        if(tweet.getIsCompleted().equals("y")){
            viewHolder.text.setTextColor(Color.parseColor("#D3D3D3"));
            viewHolder.date.setTextColor(Color.parseColor("#D3D3D3"));
            viewHolder.title.setTextColor(Color.parseColor("#D3D3D3"));
            viewHolder.date.setText(tweet.getDate());
            viewHolder.title.setText(tweet.getPseudo());
            viewHolder.text.setText(tweet.getText());
            viewHolder.avatar.setImageDrawable(new ColorDrawable(Color.argb(0,0,0,0)));
        }else{
            viewHolder.date.setText(tweet.getDate());
            viewHolder.title.setText(tweet.getPseudo());
            viewHolder.text.setText(tweet.getText());
            viewHolder.avatar.setImageDrawable(new ColorDrawable(tweet.getColor()));
        }
        return convertView;
    }

    private class TweetViewHolder{
        public TextView date;
        public TextView title;
        public TextView text;
        public ImageView avatar;
    }
}

class Comment {
    private int color;
    private String title;
    private String text;
    private String completed;
    private String important;
    private String date;

    public Comment(int color, String title,String date,String completed, String text, String important) {
        this.date=date;
        this.completed=completed;
        this.color = color;
        this.title = title;
        this.text = text;
        this.important = important;
    }
    public String getIsCompleted(){return  this.completed;}
    public String getDate(){return  this.date;}
    public String getPseudo() {
        return this.title;
    }

    public String getText() {
        return this.text;
    }

    public int getColor() {
        return this.color;
    }

    public String getImportant() { return this.important; }
}

