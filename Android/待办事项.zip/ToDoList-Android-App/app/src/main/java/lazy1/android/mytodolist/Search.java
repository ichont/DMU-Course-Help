package lazy1.android.mytodolist;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.widget.ListView;
import android.widget.TextView;
import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class Search extends AppCompatActivity {
    private TextView mTextStatus;
    private ListView mListView;
    private Comment mComment;
    private List<Comment>mtweets;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_layout);
        Intent intent=getIntent();
        String query=intent.getStringExtra("title");
        mTextStatus = (TextView) findViewById(R.id.list_status_search);
        mListView = (ListView) findViewById(R.id.list_search);
        mtweets=getSearchResults(query);
        RowAdapter adapter = new RowAdapter(Search.this, mtweets);
        mListView.setAdapter(adapter);
        if(mtweets.size() > 0 ) {
            mTextStatus.setText(R.string.app_search_notmpty);
        }
        else {
            mTextStatus.setText(R.string.app_search_empty);
        }

    }

    //重写退出函数
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Search.this.finish();
            overridePendingTransition(R.anim.no_anim, R.anim.trans_out);
        }
        return super.onKeyUp(keyCode, event);
    }
    //获取搜索结果
    public List<Comment> getSearchResults(String query){
        System.out.println(query);
        mtweets=new ArrayList<>();
        SharedPreferences myPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        String myData = myPrefs.getString("myTodoData",null);
        if(myData!=null){
            try {
                JSONArray jsonArray = new JSONArray(myData);
                for (int i = 0; i < jsonArray.length(); i++)
                {
                    String data  = jsonArray.getString(i);
                    String[] splitData = data.split("\\.");
                    if(splitData[1].indexOf(query)!=-1||splitData[0].indexOf(query)!=-1||splitData[2].indexOf(query)!=-1||splitData[4].indexOf(query)!=-1||splitData[5].indexOf(query)!=-1){
                        mtweets.add(new Comment(Integer.parseInt(splitData[0]), splitData[1], splitData[2], splitData[3],splitData[4],splitData[5]));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return mtweets;
    }

}
